<!DOCTYPE html>
<html lang="en"><head>


  
  <link rel="stylesheet" type="text/css" href="style.css">

  
  <meta charset="UTF-8">

  
  <meta http-equiv="X-UA-Compatible" content="EI=edge">

  
  <meta name="viewpoint" content="width = device-width, initial-scare =1"><title>Venues</title>
  

  
  
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  
  <style>
.jumbotron{
	background-color:#2E2D88;
	color:white;
}
/*Adds borders for tabs*/
.tab-content{
	border-left: 1px solid #add;
	border-right: 1px solid #add;
	border-bottom: 1px solid #add;
	padding: 10px;
}

.nav-tabs{
	margin-bottom: 0;
}

#frm{
	border: solid gray 1px;
	width: 55%;
	border-radius: 5px;
	margin: 100px auto;
	background: white;
	padding: 50px;
}

#btn{
	color:#fff;
	background: #337ab7;
	padding: 5px;
	margin-left: 69%;
}
#user{
	color:black;
}
#pass{
	color:black;
}
  </style></head><body>
<div class="container">
<div style="text-align: center;">
</div>
<div class="page-header">
<div style="text-align: center;">
</div>
<h1 style="text-align: center;">Don't Queue, You</h1>
</div>
<div class="jumbotron">
<p>Nearby<br>
</p>
<div>
<div style="text-align: center;">
</div>
<form action="process.php" method="post">
  <div style="text-align: center;"></div>
  <table style="text-align: left; width: 100%;" border="0" cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td style="vertical-align: top; text-align: center;"><a href="ClubLogin.php"><img style="border: 0px solid ; width: 288px; height: 197px;" alt="" src="Photos/dance-club.jpg"></a><br>
        </td>
        <td style="vertical-align: top; text-align: center;"><img style="width: 288px; height: 197px;" alt="" src="Photos/Bar.jpg"><br>
        </td>
        <td style="vertical-align: top; text-align: center;"><img style="width: 288px; height: 197px;" alt="" src="Photos/restaurant.jpg"><br>
        </td>
      </tr>
      <tr>
        <td style="vertical-align: top; text-align: center;">Club XXX<br>
        </td>
        <td style="vertical-align: top; text-align: center;">Bar XXX<br>
        </td>
        <td style="vertical-align: top; text-align: center;">Resturant XXX<br>
        </td>
      </tr>
      <tr>
        <td style="vertical-align: top;"><br>
        </td>
        <td style="vertical-align: top;"><br>
        </td>
        <td style="vertical-align: top;"><br>
        </td>
      </tr>
      <tr>
        <td style="vertical-align: top;"><br>
        </td>
        <td style="vertical-align: top;"><br>
        </td>
        <td style="vertical-align: top;"><br>
        </td>
      </tr>
    </tbody>
  </table>
  <br>
<p>&nbsp;&nbsp;&nbsp; </p>
  <p> <br>
<a href="http://localhost/Login/register.php"><small></small></a>
  </p>
</form>
</div>
</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script><!-- Use downloaded version of Bootstrap -->
<script src="js/bootstrap.min.js"></script>
</body></html>